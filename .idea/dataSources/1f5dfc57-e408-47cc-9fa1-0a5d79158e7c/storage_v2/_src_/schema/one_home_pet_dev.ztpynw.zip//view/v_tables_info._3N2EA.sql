create definer = withoutcat@`%` view v_tables_info as
select `information_schema`.`TABLES`.`TABLE_NAME`    AS `TABLE_NAME`,
       `information_schema`.`TABLES`.`TABLE_COMMENT` AS `TABLE_COMMENT`
from `information_schema`.`TABLES`
where ((`information_schema`.`TABLES`.`TABLE_SCHEMA` = database()) and
       (`information_schema`.`TABLES`.`TABLE_NAME` <> 'v_tables_info'));

